import pdfplumber
# print(pdfplumber.__version__)

# report = pdfplumber.open("c:/py/agent/deep/input.pdf").pages[0]

# len(report.curves)

# report.curves[0]

pdf_path = "c:/py/agent/deep/input.pdf"  # Replace with your actual PDF file
output_file = "extracted_output.txt"

with pdfplumber.open(pdf_path) as pdf, open(output_file, "w", encoding="utf-8") as file:
    for page_number, page in enumerate(pdf.pages, start=1):
        file.write(f"\n--- Page {page_number} ---\n\n")

        # Extract text with coordinates
        file.write("Extracted Text with Coordinates:\n")
        words = page.extract_words()
        if words:
            for word in words:
                text = word['text']
                x0, y0, x1, y1 = word['x0'], word['top'], word['x1'], word['bottom']
                file.write(f"  '{text}' at (({x0}, {y0}), ({x1}, {y1}))\n")
        else:
            file.write("No text found\n")

        # Extract curve coordinates
        file.write("\nExtracted Curves:\n")
        if page.curves:
            for i, curve in enumerate(page.curves, start=1):
                #print(f"  Curve {i}: {curve}")
                file.write(f"  Curve {i}: {curve}")
                #if "x0" in curve and "y0" in curve and "x1" in curve and "y1" in curve:
                #    x0, y0, x1, y1 = curve["x0"], curve["y0"], curve["x1"], curve["y1"]
                #    file.write(f"  Curve {i}: Start ({x0}, {y0}) -> End ({x1}, {y1})\n")
                #else:
                #    file.write(f"  Curve {i}: {curve}\n")  # Fallback for other structures
        else:
            file.write("No curves found\n")

print(f"Extraction completed. Data saved to {output_file}")
