# pip install torch timm sentence-transformers scikit-learn pillow
import torch
import timm
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from PIL import Image
import torchvision.transforms as transforms

# Step 1: Load a pre-trained vision model (ViT from timm)
vision_model = timm.create_model('vit_base_patch16_224', pretrained=True, num_classes=0)  # num_classes=0 to get features only
vision_model.eval()

# Step 2: Load a pre-trained text embedding model (Sentence-BERT)
text_model = SentenceTransformer('all-MiniLM-L6-v2')

# Step 3: Preprocess image and extract visual features
def extract_visual_features(image_path):
    # Load and preprocess the image
    image = Image.open(image_path).convert('RGB')
    preprocess = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    image_tensor = preprocess(image).unsqueeze(0)  # Add batch dimension

    # Extract features
    with torch.no_grad():
        visual_features = vision_model(image_tensor)
    return visual_features.numpy()  # Convert to numpy array

# Step 4: Parse Markdown and extract text descriptions
def parse_markdown(markdown_text):
    # Example: Extract text descriptions from Markdown
    descriptions = []
    for line in markdown_text.split('\n'):
        if line.startswith('- '):  # Example: Assume descriptions are bullet points
            descriptions.append(line[2:].strip())
    return descriptions

# Step 5: Compute similarity between visual features and text embeddings
def compute_similarity(visual_features, text_descriptions):
    # Embed text descriptions
    text_embeddings = text_model.encode(text_descriptions)

    # Compute cosine similarity
    similarities = cosine_similarity(visual_features, text_embeddings)
    return similarities

# Step 6: Map visual features to valve types based on similarity
def map_visual_to_valve_type(visual_features, text_descriptions):
    similarities = compute_similarity(visual_features, text_descriptions)
    most_similar_index = np.argmax(similarities)
    return text_descriptions[most_similar_index], similarities[0][most_similar_index]

# Predefined Markdown valve descriptions
markdown_text = """
## Valve Symbols and Their Geometric Descriptions

### 1. Ball Valve
- A **circle** at the center represents the valve body.
- Two **diagonal lines** crossing through the circle form an "X" shape, symbolizing the ball mechanism.
- Two **horizontal lines** extending outward from both sides represent the pipeline connections.

### 2. Gate Valve
- Two **diagonal lines** crossing at the center form an "X" shape.
- Two **horizontal lines** extending outward represent pipeline connections.
- Two **trapezoidal shapes** (or angled lines) on either side of the "X" symbolize the gate mechanism.

### 3. Check Valve
- Two **horizontal lines** extending outward represent pipeline connections.
- A **diagonal line** connecting these horizontal lines forms an angled structure.
- A **triangle (or arrow shape) on the diagonal line** indicates the direction of flow.
- A **small vertical segment at one end** represents the valve's hinge or stopping mechanism.

### 4. Reducer Eccentric (Flat on Bottom)
- A trapezoidal shape represents the reducer body.
- Two horizontal lines extending outward from both sides symbolize the pipeline connections.
- The larger end of the trapezoid indicates the inlet (higher diameter).
- The smaller end represents the outlet (reduced diameter).
- One side of the reducer is flat (aligned with the bottom pipeline connection), distinguishing it as an eccentric reducer.
- This symbol is used to depict a flat-bottom eccentric reducer, typically used in pipelines to prevent air pockets or ensure proper drainage.

### 5. Reducer Concentric
- A trapezoidal shape represents the reducer body.
- Two horizontal lines extending outward from both sides symbolize the pipeline connections.
- The larger end of the trapezoid indicates the inlet (higher diameter).
- The smaller end represents the outlet (reduced diameter).
- This symbol is used to depict a concentric reducer, which symmetrically reduces the pipe size along the centerline.

## 6. Hydraulic Signal
**Symbol Description:**
- A **horizontal line** representing the main hydraulic line.
- Multiple **vertical short lines** intersecting the horizontal line at regular intervals.
- Each vertical line has a **short perpendicular segment at the bottom**, forming an "L" shape.
- This represents hydraulic signal transmission points along the main line.

## 7. Electrical Transmission or Instrumentation Electrical Line
**Symbol Description:**
- A **dashed horizontal line** consisting of short, evenly spaced segments.
- Represents electrical signals, power transmission, or instrumentation wiring.
- Commonly used in schematics to indicate non-physical electrical connections.

## 8. Connection to Process or Mechanical Line
**Symbol Description:**
- A **solid horizontal line** representing a direct connection to a process or mechanical system.
- Used in schematics to indicate pipelines, conduits, or structural connections.

## 9. Radio, Sonic, or Light Signal
**Symbol Description:**
- A **horizontal line** with multiple evenly spaced, small semicircles along its length.
- Represents transmission of signals using radio waves, sound waves, or light waves.
- Commonly used in instrumentation and communication diagrams to indicate remote signal transmission.
"""

# Parse Markdown and extract text descriptions
text_descriptions = parse_markdown(markdown_text)

# Example usage
if __name__ == "__main__":
    # Path to the image
    image_path = 'example_image.jpg'  # Replace with your image path

    # Extract visual features
    visual_features = extract_visual_features(image_path)

    # Map visual features to valve types
    valve_type, similarity_score = map_visual_to_valve_type(visual_features, text_descriptions)

    # Print results
    print(f"Detected Valve Type: {valve_type}")
    print(f"Similarity Score: {similarity_score:.4f}")