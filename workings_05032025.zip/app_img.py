from groq import Groq

client = Groq()

# Predefined Markdown valve descriptions
markdown_text = """
## Valve Symbols and Their Geometric Descriptions

### 1. Ball Valve
- A **circle** at the center represents the valve body.
- Two **diagonal lines** crossing through the circle form an "X" shape, symbolizing the ball mechanism.
- Two **horizontal lines** extending outward from both sides represent the pipeline connections.

### 2. Gate Valve
- Two **diagonal lines** crossing at the center form an "X" shape.
- Two **horizontal lines** extending outward represent pipeline connections.
- Two **trapezoidal shapes** (or angled lines) on either side of the "X" symbolize the gate mechanism.

### 3. Check Valve
- Two **horizontal lines** extending outward represent pipeline connections.
- A **diagonal line** connecting these horizontal lines forms an angled structure.
- A **triangle (or arrow shape) on the diagonal line** indicates the direction of flow.
- A **small vertical segment at one end** represents the valve's hinge or stopping mechanism.
"""

# Constructing the query with Markdown text included
# Define the system role for the AI
system_prompt = """
You are an expert in Piping and Instrumentation Diagram (P&ID) analysis. 
Your task is to analyze P&ID images and extract relevant symbols, their meanings, 
and any associated specifications, tags, or instruments. You must interpret 
the diagram using standard engineering conventions.
"""

# User query with markdown-based symbol descriptions for context
user_prompt1 = f"""
Analyze the following image and extract pipelines, their specifications, valves with their tags, 
and instruments with their tags.

Use the following **Markdown-based descriptions of valve symbols** as a reference while analyzing the image:

{markdown_text}
"""
    
user_prompt = f"""
You are an expert in Piping and Instrumentation Diagram (P&ID) analysis. 
Analyze the following image and extract:
- Pipelines and their specifications
- Valves with their tags
- Instruments with their tags

Use the following **Markdown-based descriptions of valve symbols** as a reference while analyzing the image:

{markdown_text}
"""

completion = client.chat.completions.create(
    model="llama-3.2-11b-vision-preview",
    messages=[
        #{"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": user_prompt},
                # {
                    # "type": "text",
                    # "text": "extract pipelines and its spec, valves and its tags, instruments and its Tags?"
                # },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://raw.githubusercontent.com/esudas2020/imagegrafix/refs/heads/main/input01.png"
                    }
                }
            ]
        }
    ],
    temperature=1,
    max_completion_tokens=1024,
    top_p=1,
    stream=False,
    stop=None,
)

print(completion.choices[0].message)
