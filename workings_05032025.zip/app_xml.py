import streamlit as st
from pypdf import PdfReader
from streamlit_extras.add_vertical_space import add_vertical_space
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
import pickle
import os
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain.chains.question_answering import load_qa_chain
from langchain_groq import ChatGroq
from gtts import gTTS
import pytesseract
from pdf2image import convert_from_path
from PIL import Image
import pandas as pd
import json
import xml.etree.ElementTree as ET
import asyncio

# Sidebar contents
with st.sidebar:
    st.title("📄🤗 ImageGrafix PDFgpt : Chat with your PDF")
    add_vertical_space(1)
    st.markdown('''
    ### ImageGrafix PDFgpt:
    This application is an LLM-powered chatbot built using the following:
    - [Langchain](https://www.langchain.com/)
    - [Streamlit](https://streamlit.io/)
    - [Hugging Face](https://huggingface.co/)
    - [Groq](https://groq.com/groqcloud/)
    ''')
    add_vertical_space(4)
    st.write('Made with by Custom Development Team')

def text_to_speech(text, filename):
    """Convert text to speech and save as an MP3 file."""
    tts = gTTS(text)
    tts.save(filename)

def extract_text_from_page(page):
    """Extract text from a page with orientation correction using OCR if needed."""
    text = page.extract_text()
    
    if not text:  # If text extraction fails, fallback to OCR
        st.warning("Text extraction failed. Applying OCR for orientation correction.")
        return None
    return text

def ocr_extract_text(pdf):
    """Extract text from an image-based or rotated PDF using OCR."""
    images = convert_from_path(pdf)
    text = ""
    
    for image in images:
        # Use OCR to detect text in the correct orientation
        text += pytesseract.image_to_string(image)
    
    return text
# Extract text from CSV
def extract_text_from_csv(csv_file):
    df = pd.read_csv(csv_file)
    return df.to_string(index=False)  # Convert entire CSV to a string

# Extract text from JSON
def extract_text_from_json(json_file):
    data = json.load(json_file)
    return json.dumps(data, indent=2)  # Convert JSON to formatted string

# Extract text from XML
def extract_text_from_xml(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()
    return ET.tostring(root, encoding='utf8').decode('utf8')  # Convert XML to string

# Extract text from TXT
def extract_text_from_txt(txt_file):
    return txt_file.read().decode("utf-8")  # Read text as UTF-8

def main():
    st.header("Chat with your PDF📄")

    # Ask user to upload PDF
    uploaded_file  = st.file_uploader("Upload Documents", type=["pdf", "csv", "json", "xml", "txt"])
    
    if uploaded_file is not None:
        file_type = uploaded_file.type
        text = ""

        if file_type == "application/pdf":
            text = extract_text_from_pdf(uploaded_file)
        elif file_type == "text/csv":
            text = extract_text_from_csv(uploaded_file)
        elif file_type == "application/json":
            text = extract_text_from_json(uploaded_file)
        elif file_type == "text/xml" or file_type == "application/xml":
            text = extract_text_from_xml(uploaded_file)
        elif file_type == "text/plain":
            text = extract_text_from_txt(uploaded_file)

        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )

        chunks = text_splitter.split_text(text=text)
        
        # Check if chunks are not empty before proceeding
        if chunks:
            store_name = uploaded_file.name[:-4]

            if os.path.exists(f"{store_name}_chunks.pkl"):
                # Load stored chunks and recreate vector store
                with open(f"{store_name}_chunks.pkl", 'rb') as f:
                    chunks = pickle.load(f)
                
                with st.spinner("Recreating the vector store..."):
                    embeddings = SentenceTransformerEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
                    vector_store = Chroma.from_texts(chunks, embedding=embeddings)
            else:
                with st.spinner("Downloading and loading embeddings, please wait..."):
                    embeddings = SentenceTransformerEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
                
                st.success("Embeddings loaded successfully!")
                
                vector_store = Chroma.from_texts(chunks, embedding=embeddings)

                # Store the chunks for future use
                with open(f"{store_name}_chunks.pkl", "wb") as f:
                    pickle.dump(chunks, f)
            
            # Accept user question/query
            query = st.text_input("Ask questions about the Uploaded Document here:")
            
            if query:
                docs = vector_store.similarity_search(query=query, k=5)
                llm = ChatGroq(model="llama3-8b-8192")
                chain = load_qa_chain(llm=llm, chain_type="stuff")
                response = chain.run(input_documents=docs, question=query)

                # Generate a unique filename for each response to avoid caching
                # speech_file = f"response_{query.replace(' ', '_')}.mp3"
                # text_to_speech(response, speech_file)

                # Clear the previous audio player and play the new audio
                # st.audio(speech_file, format="audio/mp3")

                # Display the response text below the audio player
                st.write(response)
        else:
            st.error("No text found in Document to create chunks. Please check your Document content.")

if __name__ == "__main__":
    main()