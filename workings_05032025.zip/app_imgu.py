from groq import Groq

client = Groq()

# Predefined Markdown valve descriptions
markdown_text = """
## Valve Symbols and Their Geometric Descriptions

### 1. Ball Valve
- A **circle** at the center represents the valve body.
- Two **diagonal lines** crossing through the circle form an "X" shape, symbolizing the ball mechanism.
- Two **horizontal lines** extending outward from both sides represent the pipeline connections.

### 2. Gate Valve
- Two **diagonal lines** crossing at the center form an "X" shape.
- Two **horizontal lines** extending outward represent pipeline connections.
- Two **trapezoidal shapes** (or angled lines) on either side of the "X" symbolize the gate mechanism.

### 3. Check Valve
- Two **horizontal lines** extending outward represent pipeline connections.
- A **diagonal line** connecting these horizontal lines forms an angled structure.
- A **triangle (or arrow shape) on the diagonal line** indicates the direction of flow.
- A **small vertical segment at one end** represents the valve's hinge or stopping mechanism.

### 4.Reducer Eccentric (Flat on Bottom)
- A trapezoidal shape represents the reducer body.
- Two horizontal lines extending outward from both sides symbolize the pipeline connections.
- The larger end of the trapezoid indicates the inlet (higher diameter).
- The smaller end represents the outlet (reduced diameter).
- One side of the reducer is flat (aligned with the bottom pipeline connection), distinguishing it as an eccentric reducer.
- This symbol is used to depict a flat-bottom eccentric reducer, typically used in pipelines to prevent air pockets or ensure proper drainage.

### 5.Reducer Concentric
- A trapezoidal shape represents the reducer body.
- Two horizontal lines extending outward from both sides symbolize the pipeline connections.
- The larger end of the trapezoid indicates the inlet (higher diameter).
- The smaller end represents the outlet (reduced diameter).
- This symbol is used to depict a concentric reducer, which symmetrically reduces the pipe size along the centerline.

## 6. Hydraulic Signal
**Symbol Description:**
- A **horizontal line** representing the main hydraulic line.
- Multiple **vertical short lines** intersecting the horizontal line at regular intervals.
- Each vertical line has a **short perpendicular segment at the bottom**, forming an "L" shape.
- This represents hydraulic signal transmission points along the main line.

## 7. Electrical Transmission or Instrumentation Electrical Line
**Symbol Description:**
- A **dashed horizontal line** consisting of short, evenly spaced segments.
- Represents electrical signals, power transmission, or instrumentation wiring.
- Commonly used in schematics to indicate non-physical electrical connections.

## 8. Connection to Process or Mechanical Line
**Symbol Description:**
- A **solid horizontal line** representing a direct connection to a process or mechanical system.
- Used in schematics to indicate pipelines, conduits, or structural connections.

## 9. Radio, Sonic, or Light Signal
**Symbol Description:**
- A **horizontal line** with multiple evenly spaced, small semicircles along its length.
- Represents transmission of signals using radio waves, sound waves, or light waves.
- Commonly used in instrumentation and communication diagrams to indicate remote signal transmission.

- Sample Pipe line Number or Pipe line Specification is 4"-P-1002-15NX0P
- Do **not include explanations, descriptions, or summaries**.
- Ensure **all detected elements are listed**, avoiding missing data.

---

These geometric descriptions can serve as a reference for AI-based sketch recognition and classification. The AI model can be trained using these structured descriptions to identify different valve types, hydraulic signals, electrical transmission lines, process connections, and signal transmission lines based on their schematic representations.

"""

# Constructing the query with Markdown text included
# Define the system role for the AI
    
user_prompt = f"""
You are an expert in Piping and Instrumentation Diagram (P&ID) analysis. 
Analyze the following image and extract detailed information about:

### 1. Pipelines and Their Specifications
   - Pipeline Number
   - Start Position (X, Y)
   - End Position (X, Y)
   - Diameter (in inches)
   - Material
   - Pressure Drop (in psi)

### 2. Valves and Their Details
   - Valve Type (Ball, Gate, Check, etc.)
   - Installed on which Pipeline
   - Position (X, Y)
   - Valve Tag
   - Diameter (in inches)
   
### 2. Reducers
   - Reducer Type (Concentric)
   - Installed on which Pipeline
   - Position (X, Y)
   - Reducer Tag
   - Diameter (in inches)
   
### 3. Instruments and Their Tags
   - Instrument Type (Temperature Indicator, Pressure Gauge, etc.)
   - Position (X, Y)
   - Instrument Tag

Use the following **Markdown-based descriptions of valve symbols** as a reference while analyzing the image:

{markdown_text}

Please extract the relevant information and present it in a structured format.

"""

completion = client.chat.completions.create(
    model="llama-3.2-11b-vision-preview",
    messages=[
        #{"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": user_prompt},
                # {
                    # "type": "text",
                    # "text": "extract pipelines and its spec, valves and its tags, instruments and its Tags?"
                # },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://raw.githubusercontent.com/esudas2020/imagegrafix/refs/heads/main/input01.png"
                    }
                }
            ]
        }
    ],
    temperature=1,
    max_completion_tokens=1024,
    top_p=1,
    stream=False,
    stop=None,
)

print(completion.choices[0].message)
