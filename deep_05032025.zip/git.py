import fitz  # PyMuPDF
import os
import json

def extract_graphics_and_text(pdf_path, output_folder="extracted_data"):
    os.makedirs(output_folder, exist_ok=True)
    output_json = os.path.join(output_folder, "graphics_text_data.json")

    doc = fitz.open(pdf_path)
    extracted_data = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        print(f"\n=== Extracting data from Page {page_num + 1} ===\n")

        # ---- Extract Vector Graphics ----
        paths = page.get_drawings()
        page_data = {"page": page_num + 1, "shapes": [], "text": []}

        for path_index, path in enumerate(paths):
            shape_data = {"path_id": path_index + 1, "elements": []}

            for item in path["items"]:
                item_type = item[0]  # Drawing type
                item_data = item[1]  # Coordinates or shape

                # Convert Points, Rects, and Quads to lists
                if isinstance(item_data, fitz.Point):
                    item_data = (item_data.x, item_data.y)

                elif isinstance(item_data, fitz.Rect):
                    item_data = [item_data.x0, item_data.y0, item_data.x1, item_data.y1]

                elif isinstance(item_data, fitz.Quad):
                    item_data = [[p.x, p.y] for p in [item_data.ul, item_data.ur, item_data.ll, item_data.lr]]

                elif isinstance(item_data, list):
                    item_data = [
                        (p.x, p.y) if isinstance(p, fitz.Point) else
                        [p.x0, p.y0, p.x1, p.y1] if isinstance(p, fitz.Rect) else
                        [[p.x, p.y] for p in [p.ul, p.ur, p.ll, p.lr]] if isinstance(p, fitz.Quad) else p
                        for p in item_data
                    ]

                # Skip single points (not useful for vector graphics)
                if isinstance(item_data, tuple) and len(item_data) == 2:
                    continue

                shape_entry = {"type": item_type, "data": item_data}

                # Add descriptions for known shape types
                if item_type == "l" and len(item_data) == 4:
                    x0, y0, x1, y1 = item_data
                    shape_entry["description"] = f"Line from ({x0}, {y0}) to ({x1}, {y1})"

                elif item_type == "c" and len(item_data) == 4:
                    shape_entry["description"] = f"Bezier Curve {item_data}"

                elif item_type == "re" and len(item_data) == 4:
                    x, y, w, h = item_data
                    shape_entry["description"] = f"Rectangle at ({x}, {y}) with width {w} and height {h}"

                elif item_type == "q":
                    shape_entry["description"] = f"Quad Points: {item_data}"

                else:
                    shape_entry["description"] = f"Unknown format: {item_data}"

                shape_data["elements"].append(shape_entry)

            page_data["shapes"].append(shape_data)

        # ---- Extract Text ----
        # ---- Extract Text (Flexible Unpacking) ----
        for text_block in page.get_text("blocks"):  
            if len(text_block) >= 6:  # Ensure enough values are present
                x0, y0, x1, y1, text = text_block[:5]  # Only take the first 5 elements
                text_entry = {
                    "text": text.strip(),
                    "bounding_box": [x0, y0, x1, y1]
                }
                page_data["text"].append(text_entry)

        extracted_data.append(page_data)

    # Save extracted data as JSON
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(extracted_data, f, indent=4)

    print(f"\n✅ Data extraction complete! Saved to '{output_json}'")
# Run the function with your PDF file
extract_graphics_and_text("input.pdf")