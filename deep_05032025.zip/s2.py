import openai
import fitz  # PyMuPDF
import json
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import time

# OpenAI API Key
API_KEY = "your-openai-api-key"
client = openai.OpenAI(api_key=API_KEY)

def extract_text_from_pdf(pdf_path):
    """Extracts text content from a PDF."""
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text("text") + "\n"
    return text

def extract_graphics_from_pdf(pdf_path):
    """Extracts graphical objects (lines, circles, etc.) from a PDF."""
    doc = fitz.open(pdf_path)
    graphics = []
    for page in doc:
        for item in page.get_drawings():
            graphics.append(item)
    
    # Convert to JSON for structured representation
    graphics_json = json.dumps(graphics, default=str, indent=4)
    return graphics_json

def generate_embeddings(text):
    """Generates embeddings for the extracted text."""
    response = client.embeddings.create(
        model="text-embedding-ada-002",
        input=text
    )
    return np.array(response.data[0].embedding)

def find_relevant_text(query, text_chunks, text_embeddings):
    """Finds relevant text using cosine similarity."""
    query_embedding = generate_embeddings(query).reshape(1, -1)
    similarities = cosine_similarity(query_embedding, text_embeddings)
    best_match_idx = np.argmax(similarities)
    return text_chunks[best_match_idx]

def process_pdf_with_openai(input_pdf_path, ref_pdf_path, ref_xml_path, query):
    """Processes input PDF by extracting text, graphics, and sending to OpenAI."""
    
    # Extract text and graphics from input PDF
    input_text = extract_text_from_pdf(input_pdf_path)
    input_graphics = extract_graphics_from_pdf(input_pdf_path)

    # Extract text from reference PDF
    ref_text = extract_text_from_pdf(ref_pdf_path)

    # Split reference text into smaller chunks (for embeddings)
    text_chunks = ref_text.split("\n\n")  # Simple split by paragraphs
    text_embeddings = np.array([generate_embeddings(chunk) for chunk in text_chunks])

    # Find the most relevant reference text
    relevant_ref_text = find_relevant_text(query, text_chunks, text_embeddings)

    # Prepare OpenAI request
    messages = [
        {"role": "system", "content": "Analyze the given P&ID document and provide structured XML output similar to the reference XML."},
        {"role": "user", "content": f"Reference Text:\n{relevant_ref_text}\n\nInput Text:\n{input_text}\n\nGraphics Data:\n{input_graphics}"}
    ]

    # Send request to OpenAI
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages
    )

    return response.choices[0].message.content

if __name__ == "__main__":
    INPUT_PDF_PATH = "input.pdf"  # Target PDF for processing
    REF_PDF_PATH = "s1.pdf"  # Reference (sample) PDF
    REF_XML_PATH = "s1.xml"  # Reference XML for expected structure
    query = "Extract P&ID details and convert to XML format."

    extracted_xml = process_pdf_with_openai(INPUT_PDF_PATH, REF_PDF_PATH, REF_XML_PATH, query)

    # Save the result as XML
    with open("output.xml", "w", encoding="utf-8") as xml_file:
        xml_file.write(extracted_xml)

    print("P&ID extraction complete. Saved as output.xml.")
