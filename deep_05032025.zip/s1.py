import openai
import time

# Initialize OpenAI client
client = openai.OpenAI(api_key="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")
def upload_pdf_and_extract_details(in_path, pdf_path, xml_path, model="gpt-4o-mini"):
    """Uploads a PDF and its corresponding XML file and extracts P&ID details in XML format using Assistants API."""
    
    # Upload input PDF file
    with open(in_path, "rb") as input_pdf_file:
        input_pdf_response = client.files.create(file=input_pdf_file, purpose="assistants")
    input_pdf_file_id = input_pdf_response.id
    
    # Upload reference PDF file
    with open(pdf_path, "rb") as pdf_file:
        pdf_response = client.files.create(file=pdf_file, purpose="assistants")
    pdf_file_id = pdf_response.id
    
    # Upload XML reference file
    with open(xml_path, "rb") as xml_file:
        xml_response = client.files.create(file=xml_file, purpose="assistants")
    xml_file_id = xml_response.id
    
    # Create Assistant with File Search capability
    assistant = client.beta.assistants.create(
        name="P&ID Extractor",
        instructions="Extract P&ID details from the uploaded document and return structured XML similar to the reference XML.",
        model=model,
        tools=[{"type": "file_search"}]  # Corrected tool type
    )

    # Create a Thread
    thread = client.beta.threads.create()

    # Attach files to Thread
    message = client.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content="Analyze the P&ID from the uploaded PDF and generate an XML output following the reference XML.",
        file_ids=[input_pdf_file_id, pdf_file_id, xml_file_id]
    )

    # Run Assistant on Thread
    run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=assistant.id)

    # Wait for completion
    while run.status not in ["completed", "failed"]:
        time.sleep(3)
        run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)

    # Retrieve the response
    messages = client.beta.threads.messages.list(thread_id=thread.id)
    extracted_xml = messages.data[0].content[0].text.value

    return extracted_xml

if __name__ == "__main__":
    API_KEY = "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"
    PDF_PATH = "s1.pdf"  # Reference PDF
    XML_PATH = "s1.xml"  # Reference XML
    INPUT_PDF_PATH = "input.pdf"  # Target PDF for extraction
    
    extracted_xml = upload_pdf_and_extract_details(INPUT_PDF_PATH, PDF_PATH, XML_PATH)

    # Save output as XML file
    with open("output.xml", "w", encoding="utf-8") as xml_file:
        xml_file.write(extracted_xml)

    print("XML extraction complete. Saved as output.xml.")
