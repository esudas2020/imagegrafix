import fitz  # PyMuPDF
from openai import OpenAI

OPENAI_API_KEY = "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"

client = OpenAI(api_key=OPENAI_API_KEY)

# pstr = "Generate a autolisp command for AutoCAD to draw a circle with 40,70 and radius of 665 '''Example: (command \"line\" \"0,0\" \"4,4\" \"\") '''Instruction: generate exactly script alone, without any other details"
# completion = client.chat.completions.create(model="gpt-4o-mini", store=True,messages=[{"role": "user", "content": pstr}])
# print(completion.choices[0].message);

# Set OpenAI API Key -- igfx key
# OPENAI_API_KEY = "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"

# Function to extract text and coordinates from a PDF
def extract_text_with_coordinates(pdf_path):
    doc = fitz.open(pdf_path)
    extracted_data = []

    for page in doc:
        for text_block in page.get_text("blocks"):  # Extract text blocks
            x0, y0, x1, y1, text = text_block[:5]
            extracted_data.append({
                "text": text.strip(),
                "coordinates": (x0, y0, x1, y1),
                "page": page.number + 1
            })
    
    return extracted_data

# Function to classify component type using GPT-4o-mini
def classify_component(text):
    prompt = f"Identify the type of piping component from this description: '{text}'. \
    Examples: Gate Valve, Check Valve, Ball Valve, Pipe Run, Flange, Elbow, Pump."

    completion = client.chat.completions.create(
        model="gpt-4o-mini", store=True,
        messages=[{"role": "system", "content": "You are an expert in P&ID interpretation."},
                  {"role": "user", "content": prompt}],
        #api_key=OPENAI_API_KEY
    )
    
    return completion.choices[0].message.content.strip() #completion['choices'][0]['message']['content'].strip()

# Main function to process the P&ID
def analyze_pid(pdf_path):
    extracted_data = extract_text_with_coordinates(pdf_path)
    
    # Classify components
    for item in extracted_data:
        item["component_type"] = classify_component(item["text"])
    
    return extracted_data

# Example usage
pdf_path = "input.pdf"
pid_data = analyze_pid(pdf_path)

# Print extracted data
for item in pid_data:
    print(f"Page {item['page']} - {item['component_type']} - {item['text']} - Coordinates: {item['coordinates']}")

with open("pid_data.txt", "w", encoding="utf-8") as file:
    for item in pid_data:
        file.write(f"Page {item['page']} - {item['component_type']} - {item['text']} - Coordinates: {item['coordinates']}\n")
