from openai import OpenAI

client = OpenAI(
  api_key="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"
)

pstr = "Generate a autolisp command for AutoCAD to draw a circle with 40,70 and radius of 665 '''Example: (command \"line\" \"0,0\" \"4,4\" \"\") '''Instruction: generate exactly script alone, without any other details"

completion = client.chat.completions.create(
  model="gpt-4o-mini",
  #model="gpt-3.5-turbo", #"gpt-4o-mini",
  store=True,
  messages=[
    {"role": "user", "content": pstr}
  ]
)

print(completion.choices[0].message);
