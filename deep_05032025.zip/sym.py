import cv2
import numpy as np
import os

# Create output directory if not exists
output_dir = "output"
os.makedirs(output_dir, exist_ok=True)

# Load image
image = cv2.imread("input.png", cv2.IMREAD_GRAYSCALE)

# Apply adaptive threshold to enhance symbols
binary = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                               cv2.THRESH_BINARY_INV, 11, 2)

# Use morphological transformations to remove noise (small letters)
kernel = np.ones((5, 5), np.uint8)
cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)

# Find contours
contours, _ = cv2.findContours(cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Set min & max area to filter out small letters & large non-symbol regions
min_area = 100  # Adjust based on symbol size
max_area = 200

# Loop through contours and extract symbols
for i, cnt in enumerate(contours):
    area = cv2.contourArea(cnt)
    
    if min_area < area < max_area:  # Filter out small text & large components
        x, y, w, h = cv2.boundingRect(cnt)
        symbol = image[y:y+h, x:x+w]
        
        # Save cropped symbol in 'output' folder
        symbol_path = os.path.join(output_dir, f"cropped_symbol_{i}.png")
        cv2.imwrite(symbol_path, symbol)

print(f"Symbol cropping completed! Cropped symbols saved in '{output_dir}' folder.")
