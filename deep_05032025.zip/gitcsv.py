import fitz  # PyMuPDF
import os
import json

def extract_graphics_and_text(pdf_path, output_folder="extracted_data"):
    os.makedirs(output_folder, exist_ok=True)
    output_txt = os.path.join(output_folder, "graphics_text_data.txt")

    doc = fitz.open(pdf_path)
    
    with open(output_txt, "w", encoding="utf-8") as f:
        for page_num in range(len(doc)):
            page = doc[page_num]
            f.write(f"\n=== Page {page_num + 1} ===\n")

            # ---- Extract Vector Graphics ----
            paths = page.get_drawings()
            for path_index, path in enumerate(paths):
                for item in path["items"]:
                    item_type = item[0]  # Shape type
                    item_data = item[1]  # Coordinates

                    # Convert Points, Rects, and Quads to a readable format
                    if isinstance(item_data, fitz.Point):
                        item_data = f"Point({item_data.x}, {item_data.y})"
                    elif isinstance(item_data, fitz.Rect):
                        item_data = f"Rect({item_data.x0}, {item_data.y0}, {item_data.x1}, {item_data.y1})"
                    elif isinstance(item_data, fitz.Quad):
                        item_data = f"Quad({[(p.x, p.y) for p in [item_data.ul, item_data.ur, item_data.ll, item_data.lr]]})"
                    elif isinstance(item_data, list):
                        item_data = "; ".join([
                            f"Point({p.x}, {p.y})" if isinstance(p, fitz.Point) else
                            f"Rect({p.x0}, {p.y0}, {p.x1}, {p.y1})" if isinstance(p, fitz.Rect) else
                            f"Quad({[(p.x, p.y) for p in [p.ul, p.ur, p.ll, p.lr]]})" if isinstance(p, fitz.Quad) else str(p)
                            for p in item_data
                        ])
                    
                    f.write(f"Shape {path_index + 1}, Type: {item_type}, Data: {item_data}\n")

            # ---- Extract Text Blocks ----
            for text_block in page.get_text("blocks"):
                if len(text_block) >= 6:
                    x0, y0, x1, y1, text = text_block[:5]
                    f.write(f"Text: \"{text.strip()}\", Position: ({x0}, {y0}, {x1}, {y1})\n")

    print(f"\n✅ Extraction complete! Data saved in '{output_txt}'.")
    
# Run the function with your PDF file
extract_graphics_and_text("input.pdf")